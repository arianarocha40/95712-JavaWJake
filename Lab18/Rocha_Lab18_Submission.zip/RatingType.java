package com.example;

public enum RatingType {
    LOW,
    MEDIUM,
    HIGH;
}
