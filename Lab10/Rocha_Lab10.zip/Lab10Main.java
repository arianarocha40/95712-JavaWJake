import DataPackage.DataSnooper;

public class Lab10Main {
    public static void main(String[] args) {
        DataSnooper.main(args);

        //Old Code
        //DataSnooper snooper = new DataSnooper();
        //snooper.snoop();
    }
}
