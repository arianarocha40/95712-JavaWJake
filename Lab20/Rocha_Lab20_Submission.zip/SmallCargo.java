package com.example;

public class SmallCargo extends Cargo {

    public SmallCargo(int length, int width) {
        super(length, width);
        contents = "SMALL";
    }
}
