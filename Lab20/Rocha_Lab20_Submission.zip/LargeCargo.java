package com.example;

public class LargeCargo extends Cargo {
    public LargeCargo(int length, int width) {
        super(length, width);
        contents = "LARGE";
    }
}
