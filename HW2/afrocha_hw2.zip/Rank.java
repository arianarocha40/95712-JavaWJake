// Name: Ariana Rocha
// Andrew ID: afrocha
// JAVA HW 2

package com.example;

public enum Rank {
    REGULAR, SERGEANT, CAPTAIN, INSPECTOR
}
